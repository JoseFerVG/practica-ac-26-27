# =====================================================================
# Práctica 1 AC — Credit Approval (UCI) — parte de Artem Vaskevych
# Qué hace: lectura y partición train/test, EDA, imputación de NA,
#           SEC1 (atípicos, log, prueba de añadir/quitar variable),
#           Naive Bayes con caret (tuneGrid + 10-fold CV) y PCA.
# Salidas:  credit_limpio.rds (train/test limpios) y modelo_nb.rds
# Uso:      abrir P1.Rproj y ejecutar el script entero (Source).
# =====================================================================

library(ggplot2)
library(caret)

# ---------------------------------------------------------------------
# 1. Lectura y partición
#    na.strings = "?" ANTES de partir: si no, los "?" quedan como texto
#    y V2/V14 se leen como chr (error del script original del grupo).
# ---------------------------------------------------------------------
credit <- read.csv("crx.data", header = FALSE, na.strings = "?", stringsAsFactors = TRUE)
names(credit)[16] <- "Granted"            # V16 = la clase (¿se concede el crédito?)
levels(credit$Granted) <- c("no", "si")   # "-" -> no, "+" -> si (caret no admite + y -)

credit.trainIdx    <- readRDS("credit.trainIdx.rds")   # índices oficiales (586 filas)
credit.Datos.Train <- credit[credit.trainIdx, ]
credit.Datos.Test  <- credit[-credit.trainIdx, ]
stopifnot(nrow(credit.Datos.Train) == 586, nrow(credit.Datos.Test) == 104)

num <- c("V2", "V3", "V8", "V11", "V14", "V15")       # variables numéricas

# ---------------------------------------------------------------------
# 2. EDA (solo train)
#    Clases 325 no / 261 si (55/45 %) -> conjunto equilibrado.
#    V9 es la variable más fuerte (t -> casi siempre si); V8 y V11 también
#    separan; V2 y V14 apenas. Edad mínima 13,75 -> sospechosa, se comenta.
# ---------------------------------------------------------------------
colSums(is.na(credit.Datos.Train))   # NA: V1 12, V2 12, V4 6, V5 6, V6 9, V7 9, V14 13
summary(credit.Datos.Train)

ggplot(credit.Datos.Train, aes(x = V2)) + geom_histogram(bins = 30)
featurePlot(x = credit.Datos.Train[, num], y = credit.Datos.Train$Granted,
            plot = "box", scales = list(y = list(relation = "free")))
ggplot(credit.Datos.Train, aes(x = V8)) + geom_histogram(bins = 30) + facet_wrap(~ Granted)
ggplot(credit.Datos.Train, aes(x = V9)) + geom_bar() + facet_wrap(~ Granted)

# ---------------------------------------------------------------------
# 3. Imputación de NA
#    Los parámetros (mediana / moda) se calculan SOLO con train y se
#    aplican igual a test: así no se filtra información del test.
#    Numéricas -> mediana (robusta a atípicos); categóricas -> moda.
# ---------------------------------------------------------------------
for (v in c("V2", "V14")) {
  med <- median(credit.Datos.Train[[v]], na.rm = TRUE)   # V2 = 28,54 ; V14 = 160
  credit.Datos.Train[[v]][is.na(credit.Datos.Train[[v]])] <- med
  credit.Datos.Test[[v]][is.na(credit.Datos.Test[[v]])]   <- med
  cat(v, "-> mediana", med, "\n")
}
for (v in c("V1", "V4", "V5", "V6", "V7")) {
  moda <- names(which.max(table(credit.Datos.Train[[v]])))   # b, u, g, c, v
  credit.Datos.Train[[v]][is.na(credit.Datos.Train[[v]])] <- moda
  credit.Datos.Test[[v]][is.na(credit.Datos.Test[[v]])]   <- moda
  cat(v, "-> moda", moda, "\n")
}
stopifnot(sum(is.na(credit.Datos.Train)) == 0, sum(is.na(credit.Datos.Test)) == 0)

# ---------------------------------------------------------------------
# 4. SEC1 — valores atípicos
#    Regla 1,5·IQR: V2 17, V3 15, V8 52, V11 68, V14 12, V15 83 atípicos.
#    Quitar todas esas filas eliminaría ~1/3 del train y justo a los
#    clientes con más ingresos/historial -> NO se eliminan: son valores
#    reales de distribuciones muy asimétricas, no errores.
# ---------------------------------------------------------------------
par(mfrow = c(2, 3)); for (v in num) boxplot(credit.Datos.Train[[v]], main = v)
sapply(num, function(v) length(boxplot.stats(credit.Datos.Train[[v]])$out))

# log1p(x) = log(1 + x): comprime la cola derecha y admite ceros
# (log(0) = -Inf). Es una fórmula fija, sin parámetros -> se aplica
# a train y test por separado sin riesgo de fuga.
tr.log <- credit.Datos.Train; te.log <- credit.Datos.Test
for (v in c("V14", "V15")) { tr.log[[v]] <- log1p(tr.log[[v]]); te.log[[v]] <- log1p(te.log[[v]]) }
par(mfrow = c(1, 2)); boxplot(tr.log$V14, main = "log V14"); boxplot(tr.log$V15, main = "log V15")

# Prueba de AÑADIR variable: el 43,7 % tiene V15 = 0 (grupo propio).
# V15.cero = "si" si V15 == 0. Concesión: 49 % (V15 > 0) vs 38 % (V15 = 0).
mean(credit.Datos.Train$V15 == 0)
tr.log$V15.cero <- factor(ifelse(tr.log$V15 == 0, "si", "no"))
te.log$V15.cero <- factor(ifelse(te.log$V15 == 0, "si", "no"))
prop.table(table(tr.log$V15.cero, tr.log$Granted), 1)

# ---------------------------------------------------------------------
# 5. Naive Bayes (caret, method = "nb") con tuneGrid y 10-fold CV
#    fL = corrección de Laplace; usekernel = densidad kernel (TRUE) o
#    normal (FALSE); adjust = suavizado del kernel. Misma semilla en
#    todos los modelos -> mismas particiones -> comparación justa.
# ---------------------------------------------------------------------
ctrl <- trainControl(method = "cv", number = 10)
grid <- expand.grid(fL = c(0, 1), usekernel = c(TRUE, FALSE), adjust = c(0.5, 1, 2))
x.sin.clase <- function(d) d[, setdiff(names(d), "Granted")]   # predictores sin la clase

# a) Interfaz de fórmula (Granted ~ .): caret convierte los factores en
#    dummies 0/1; con usekernel = FALSE alguna dummy tiene sd = 0 en un
#    fold -> NaN. Mejor: 0,768 (TRUE, adjust 2).
set.seed(42)
nb.formula <- train(Granted ~ ., data = credit.Datos.Train, method = "nb",
                    trControl = ctrl, tuneGrid = grid)
nb.formula

# b) Interfaz x/y: los factores se modelan como categorías.
#    FALSE ya funciona (0,766); mejor 0,812 (fL 0, TRUE, adjust 1).
set.seed(42)
nb.xy <- train(x = x.sin.clase(credit.Datos.Train), y = credit.Datos.Train$Granted,
               method = "nb", trControl = ctrl, tuneGrid = grid)
nb.xy

# c) x/y + log V14/V15 + V15.cero: FALSE 0,822; mejor 0,846 (fL 0, TRUE, adjust 1).
set.seed(42)
nb.xy.log <- train(x = x.sin.clase(tr.log), y = tr.log$Granted,
                   method = "nb", trControl = ctrl, tuneGrid = grid)
nb.xy.log

# d) Igual que c) pero SIN V15.cero: 0,845 / Kappa 0,680. La diferencia
#    (0,16 puntos) es ruido de la CV -> se QUITA V15.cero (parsimonia).
tr.final <- tr.log[, names(tr.log) != "V15.cero"]
te.final <- te.log[, names(te.log) != "V15.cero"]
set.seed(42)
nb.final <- train(x = x.sin.clase(tr.final), y = tr.final$Granted,
                  method = "nb", trControl = ctrl,
                  tuneGrid = expand.grid(fL = 0, usekernel = TRUE, adjust = 1))
nb.final$results[, c("Accuracy", "Kappa")]

# Resumen (accuracy 10-fold CV): 0,7525 por defecto -> 0,768 tuneGrid ->
# 0,812 interfaz x/y -> 0,846 log V14/V15 -> V15.cero no aporta.
# El test (104) NO se usa aquí: la evaluación final la hace el grupo.

# ---------------------------------------------------------------------
# 6. Guardar para el grupo
# ---------------------------------------------------------------------
saveRDS(list(train = tr.final, test = te.final), "credit_limpio.rds")
saveRDS(nb.final, "modelo_nb.rds")

# ---------------------------------------------------------------------
# 7. PCA (solo numéricas, solo train, escaladas: si no, la variable con
#    números más grandes dominaría la PC1)
#    PVE acumulada: PC1 36 %, PC2 54 %, PC4 81 % -> hacen falta 4 de 6
#    componentes para el 80 %: variables poco correlacionadas, PCA no
#    reduce mucho. PC1 ~ "solvencia" (V3, V8, V11, V15); V14 en sentido
#    opuesto. PC1 alta -> sobre todo "si", pero las clases se solapan.
# ---------------------------------------------------------------------
pca <- prcomp(tr.final[, num], scale. = TRUE)
summary(pca)
par(mfrow = c(1, 1))
ggplot(data.frame(pca$x[, 1:2], Granted = tr.final$Granted),
       aes(PC1, PC2, color = Granted)) + geom_point(alpha = 0.6)
biplot(pca, xlabs = rep("·", nrow(pca$x)), cex = 0.8)
